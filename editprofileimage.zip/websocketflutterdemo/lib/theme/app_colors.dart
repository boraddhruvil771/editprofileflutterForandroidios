import 'dart:ui';

import 'package:flutter/material.dart';

abstract class AppColors {
  static MaterialColor createMaterialColor(Color color) {
    List strengths = <double>[.05];
    Map<int, Color> swatch = {};
    final int r = color.red, g = color.green, b = color.blue;

    for (int i = 1; i < 10; i++) {
      strengths.add(0.1 * i);
    }
    for (var strength in strengths) {
      final double ds = 0.5 - strength;
      swatch[(strength * 1000).round()] = Color.fromRGBO(
        r + ((ds < 0 ? r : (255 - r)) * ds).round(),
        g + ((ds < 0 ? g : (255 - g)) * ds).round(),
        b + ((ds < 0 ? b : (255 - b)) * ds).round(),
        1,
      );
    }
    return MaterialColor(color.value, swatch);
  }

  static const Color whiteColor = Color(0xFFFFFFFF);
  static const Color lightBlackColor = Color(0xFF212121);
  static const Color blackColor = Color(0xFF000000);
  static const Color transparent = Colors.transparent;
  static const Color lightGreenColor = Color(0xFF719633);
  static const Color darkGreenColor = Color(0xFF00923A);
  static const Color lightYellowColor = Color(0xFFFFE428);
  static const Color darkYellowColor = Color(0xFFFFFF00);
  static const Color gray42 = Color(0xFF6B6B6B);
  static const Color darkGray = Color(0xFF3A3A3A);
  static const Color extraLightGray = Color(0xFFDDDDDD);
  static const Color tfPlaceholderColor = Color(0xFFBDBDBD);
  static const Color socialLoginBorderColor = Color(0xFFEEEEEE);
  static const Color otpInactiveColor = Color(0xFF9A9A9A);
  static const Color whiteSmokeColor = Color(0xFFF6F6F6);
  static const Color yellowColor = Color(0xFFFFC531);
  static const Color darkBlueColor = Color(0xFF437AA4);
  static const Color redColor = Color(0xFFFF4C48); //Color(0xFFF11212);
  static const Color shadowColor = Color(0xFFD6D6D6);
  static const Color purpleColor = Color(0xFF9640CC);
  static const Color blueColor = Color(0xFF2C7DFF);
  static const Color extraLightGreenColor = Color(0xFFF2F8F2);
  static const Color matchDetailsBorder = Color(0xFFEEEEEE);
  static const Color violetColor = Color(0xFF6635D5);
  static const Color openMatchColor = Color(0xFFf8a930);
  static const Color scheduleColor = Color(0xFFf24523);
  static const Color upcomingColor = Color(0xFFE90C69);
  static const Color recentColor = Color(0xFF1591d5);
  static const Color lightBlueColor = Color(0xFF2D8ABC);
  static const Color thinLightGreenColor = Color(0xFF7ABC2D);
  static const Color popupMenuSelectorColor = Color(0xFFF3F3F3);
  static const Color chatBubbleColor = Color(0xFFE9F8EB);
  static const Color cFFFF80 = Color(0xFFFFFF80);
  static const Color c1382D6 = Color(0xFF1382D6);
  static const Color tealColor = Color(0xFF289B91);
  static const Color pinkColor = Color(0xFFD34D94);
  static const Color glaucousColor = Color(0xFF597BBE);
  static const Color brownYellowColor = Color(0xFFA59800);

  static const Color openPlayColor = Color(0xFF5E17EB);
  static const Color tournamentColor = Color(0xFFFF7A28);
  static const Color lessionColor = Color(0xFF0CC0DF);
  static const Color leagueColor = Color(0xFFFF66C4);
  static const Color greenColor = Color(0xFF59BB36);

  static const Color themeColor = Color(0xfff5a623);
  static const Color primaryColor = Color(0xff203152);
  static const Color greyColor = Color(0xffaeaeae);
  static const Color greyColor2 = Color(0xffE8E8E8);
  static const Color greyColor3 = Color(0xffeaeaea);
  static const Color greyColor4 = Color(0xff989898);
}
