abstract class Dimens {
  static const double fontSize7 = 7;
  static const double fontSize8 = 8;
  static const double fontSize10 = 10;
  static const double fontSize11 = 11;
  static const double fontSize12 = 12;
  static const double fontSize13 = 13;
  static const double fontSize14 = 14;
  static const double fontSize15 = 15;
  static const double fontSize17 = 17;
  static const double fontSize16 = 16;
  static const double fontSize18 = 18;
  static const double fontSize20 = 20;
  static const double fontSize22 = 22;
  static const double fontSize24 = 24;
  static const double fontSize25 = 25;
  static const double fontSize26 = 26;

  ///Height
  static const double height20 = 20;
  static const double height30 = 30;
  static const double newsHeight = 443;
  static const double newsSliderHeight = 300;
  static const double playOfWeekHeight = 380;
  static const double size12 = 12;
  static const double size11 = 11;
  static const double bannerHeight = 245.0;
  static const double zero = 0;
  static const double congratulationHeight = 438.0;
  static const double flocklerEventsHeight = 450.0;
  static const double congratulationInnerHeight = 408.0;

  /// Image Size
  static const double imageHeight = 150;
  static const double imageWidth = 120;
  static const double imageWidth130 = 130;

  ///Date time column
  static const int dateTimeColumn = 5;

  ///Common image ratio
  static const double imgRatio02 = 0.2;
  static const double imgRatio021 = 0.21;
  static const double imgRatio024 = 0.24;
  static const double imgRatio15 = 0.15;
  static const double imgRatio05 = 0.5;
  static const double imgRatio06 = 0.6;
  static const double imgRatio08 = 0.8;

  ///Common text heights
  static const double textHeightNormal = 1;
  static const double textHeightLarge = 1.2;
  static const double textHeightXLarge = 1.33;
  static const double textHeightXXLarge = 1.43;

  /// On boarding height
  static const double minHeight = 73;

  ///Common radius sizes
  static const double radius2 = 2;
  static const double radius4 = 4;
  static const double radius6 = 6;
  static const double radius8 = 8;
  static const double radius10 = 10;
  static const double radius16 = 16;
  static const double radius24 = 24;
  static const double radius40 = 40;
  static const double radius56 = 56;

  ///Other constants
  static const double iconSize7 = 7;
  static const double iconSize10 = 10;
  static const double iconSize11 = 11;
  static const double iconSize12 = 12;
  static const double iconSize13 = 13;
  static const double iconSize14 = 14;
  static const double iconSize16 = 16;
  static const double iconSize15 = 15;
  static const double iconSize18 = 18;
  static const double iconSize20 = 20;
  static const double iconSize22 = 22;
  static const double iconSize24 = 24;
  static const double iconSize28 = 28;
  static const double iconSize30 = 30;
  static const double iconSize32 = 32;
  static const double iconSize35 = 35;
  static const double iconSize40 = 40;
  static const double iconSize50 = 50;

  ///Common border widths
  static const double borderWidthSmall = 1;
  static const double borderWidthMedium = 1.5;
  static const double borderWidthLarge = 2;
  static const double borderWidthXlarge = 3;

  ///Common elevation size
  static const double elevation2 = 2;

  ///Navigation Bar
  static const double navigationBarHeight = 60;
  static const double commentBarHeight = 75;

  ///Tab Bar
  static const double tabBarHeight = 56;
  static const double tabBarIndicatorHeight = 3.0;

  //Toolbar
  static const double toolbarExpanded = 180;
  static const double keyboardToolbarHeight = 44;

  ///Loader
  static const double loaderSizeSmall = 24;
  static const double loaderSizeNormal = 48;

  ///Padding
  static const double pad0 = 0;
  static const double pad1 = 1;
  static const double pad2 = 2;
  static const double pad3 = 3;
  static const double pad4 = 4;
  static const double pad5 = 5;
  static const double pad6 = 6;
  static const double pad8 = 8;
  static const double pad10 = 10;
  static const double pad12 = 12;
  static const double pad14 = 14;
  static const double pad15 = 15;
  static const double pad16 = 16;
  static const double pad18 = 18;
  static const double pad20 = 20;
  static const double pad22 = 22;
  static const double pad25 = 25;
  static const double pad30 = 30;
  static const double pad35 = 35;
  static const double pad40 = 40;
  static const double pad50 = 50;
  static const double pad55 = 55;
  static const double pad58 = 58;
  static const double pad60 = 60;
  static const double pad68 = 68;
  static const double pad78 = 78;
  static const double pad80 = 80;
  static const double pad82 = 82;
  static const double pad90 = 90;
  static const double pad100 = 100;
  static const double pad115 = 115;
  static const double pad130 = 130;
  static const double pad150 = 150;
  static const double pad160 = 160;
  static const double pad170 = 170;
  static const double pad200 = 200;

  /// Width
  static const double w58 = 58;
  static const double w60 = 58;
  static const double w120 = 120;

  ///Height
  static const double h8 = 8;
  static const double h12 = 12;
  static const double h14 = 14;
  static const double h16 = 16;
  static const double h20 = 20;
  static const double h24 = 24;
  static const double h30 = 30;
  static const double h32 = 32;
  static const double h35 = 35;
  static const double h40 = 40;
  static const double h50 = 50;
  static const double h52 = 52;
  static const double h55 = 55;
  static const double h58 = 58;
  static const double h60 = 60;
  static const double pad71 = 71;
  static const double h75 = 75;
  static const double h70 = 70;
  static const double h45 = 45;
  static const double h80 = 80;
  static const double h85 = 85;
  static const double h100 = 100;
  static const double h110 = 110;
  static const double h115 = 115;
  static const double h120 = 120;
  static const double h125 = 125;
  static const double h135 = 135;
  static const double h150 = 150;
  static const double h180 = 180;
  static const double h300 = 300;
  static const double h360 = 360;
  static const double h400 = 400;
  static const double h750 = 750;

  static const double h520 = 520;
  static const double h480 = 480;

  ///Dynamic length

  static const double containerSize65 = 65;
  static const double containerSize50 = 50;

  static const double containerSize260 = 260;
  static const double containerSize280 = 280;
  static const double containerSize240 = 240;
}
