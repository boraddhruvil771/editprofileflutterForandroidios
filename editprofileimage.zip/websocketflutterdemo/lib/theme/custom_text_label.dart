import 'package:flutter/cupertino.dart';

/// Custom text widget
class CustomTextLabel extends StatelessWidget {
  final String label;
  final TextStyle? style;
  final TextOverflow? overflow;
  final int? maxLines;
  final TextAlign? textAlign;

  const CustomTextLabel(
      {Key? key,
      this.label = "",
      this.style,
      this.overflow = TextOverflow.ellipsis,
      this.maxLines = 3,
      this.textAlign = TextAlign.center,
      })
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      label,
      style: style ?? style,
      overflow: overflow,
      maxLines: maxLines,
      textAlign: textAlign,
      softWrap: true,
    );
  }
}
